import { Fragment } from "react";
import {
  BrowserRouter,
  Redirect,
  Route,
  Router,
  Switch,
} from "react-router-dom";
import "./App.css";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";

//components
// import Header from './components/headers/Header'
import SignUp from "./pages/SignUp";

function App() {
  const token = 0;

  // if (token == 0) {
  //   return (
  //     <Fragment>
  //       <BrowserRouter>
  //         <Switch>
  //           <Route exact path="/login" component={Login}></Route>

  //           <Route
  //             render={() => {
  //               return <Redirect to="/login" />;
  //             }}
  //           />
  //         </Switch>
  //         ;
  //       </BrowserRouter>
  //       ;
  //     </Fragment>
  //   );
  // }

  return (
    <Fragment>
      <Login />
      {/* <BrowserRouter>
      <Switch>
        <Route exact path="/" component={Login}></Route>
      </Switch>
      </BrowserRouter> */}
    </Fragment>
  );
}

export default App;
